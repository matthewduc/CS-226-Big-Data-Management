Executing script.bash will compile code into a JAR file, run program on nasa.tsv, and produce two output files "task1.txt" & "task2.txt"

Runtimes for each task are displayed in terminal in milliseconds